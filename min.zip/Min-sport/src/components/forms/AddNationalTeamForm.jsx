import React, { useState, useEffect } from 'react';
import axiosInstance from '../../utils/axiosInstance';

const AddNationalTeamForm = () => {
  const [formData, setFormData] = useState({
    teamName: 'Senior Men\'s National Team',
    teamMonth: 'JUN',
    teamYear: 2024,
    federationId: 1,
    competition: 'World Cup Qualifiers',
    city: 'Kigali',
    country: 'Rwanda',
    games: [
      {
        stadium: 'Amahoro National Stadium'
      }
    ]
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleGamesChange = (index, e) => {
    const { name, value } = e.target;
    const updatedGames = [...formData.games];
    updatedGames[index] = { ...updatedGames[index], [name]: value };
    setFormData((prevData) => ({
      ...prevData,
      games: updatedGames
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axiosInstance.post('/path/to/api/endpoint', formData);
      console.log('Form submitted successfully:', response);
      // Handle success, e.g., show success message, reset form, etc.
    } catch (error) {
      console.error('Error submitting form:', error);
      // Handle error, e.g., show error message
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Team Name:</label>
        <input
          type="text"
          name="teamName"
          value={formData.teamName}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Month:</label>
        <input
          type="text"
          name="teamMonth"
          value={formData.teamMonth}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Year:</label>
        <input
          type="number"
          name="teamYear"
          value={formData.teamYear}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Federation ID:</label>
        <input
          type="number"
          name="federationId"
          value={formData.federationId}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Competition:</label>
        <input
          type="text"
          name="competition"
          value={formData.competition}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>City:</label>
        <input
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
        />
      </div>
      <div>
        <label>Country:</label>
        <input
          type="text"
          name="country"
          value={formData.country}
          onChange={handleChange}
        />
      </div>

      {/* Handle games input dynamically */}
      {formData.games.map((game, index) => (
        <div key={index}>
          <label>Stadium:</label>
          <input
            type="text"
            name="stadium"
            value={game.stadium}
            onChange={(e) => handleGamesChange(index, e)}
          />
        </div>
      ))}

      <button type="submit">Submit</button>
    </form>
  );
};

export default AddNationalTeamForm;
